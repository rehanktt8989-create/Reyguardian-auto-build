#!/bin/bash
# Simple helper to list Gradle assemble tasks available
./gradlew tasks --all | grep assemble | sed -n '1,200p'
echo 'To build lite or full flavors, run: ./gradlew assembleDebug or ./gradlew assembleFullDebug (if flavor exists)'
