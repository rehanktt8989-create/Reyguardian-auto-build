ReyGuardian - Automated APK build package (Phone-only guide)
============================================================

Goal:
- Build ReyGuardian APK automatically using GitHub Actions, entirely from your Android phone (no PC needed).
- Two modes: MODE1 (Lite) and MODE2 (Full). Both are build variants controlled by Gradle flavors (included in project).
- After build, APK artifact will be available in Actions -> Artifacts for download to your phone.

Steps (phone-only):
1. Create a GitHub account (if you don't have one) using the GitHub app or mobile browser.
2. On your phone, open GitHub web and create a new repository (name it `reyguardian-auto-build`). Keep it public or private.
3. Upload the project files:
   - On GitHub mobile UI, go to the new repo, choose 'Add file' -> 'Upload files' and upload *all files* from the project folder in this ZIP.
   - Important: ensure `.github/workflows/android-build.yml` is in the repo path exactly as `.github/workflows/android-build.yml`.
4. Once files are uploaded and committed to the default branch (main), GitHub Actions will trigger automatically.
5. Open the repository in GitHub mobile app or browser -> Actions -> select the latest workflow run -> wait for the 'Upload APK artifact' step to finish.
6. After successful run, go to 'Artifacts', download `ReyGuardian-apk` artifact (it contains `app-debug.apk`). Download to your phone storage.
7. Install APK:
   - If needed, enable Install unknown apps for your browser/File Manager.
   - Install the `app-debug.apk`. Open app and grant Notification Access when prompted.
8. Usage:
   - MODE1 (Lite): default debug build acts as Lite mode. To build Full mode, you may modify gradle flavors in the project (instructions included in project README).

Notes:
- The APK produced by this workflow is a DEBUG build signed with the debug key (not suitable for Play Store).
- Building may take several minutes; artifacts are stored for a limited time by GitHub (typically 90 days for private repos).
- If you cannot upload all files via mobile due to size limits, create the repo and upload just the `.github/workflows/android-build.yml` and a `build-script` that fetches remaining files from this ZIP hosted somewhere (or contact me for alternatives).
- If your phone storage is low, download the artifact directly from GitHub Actions to cloud storage (Google Drive) and then install via the Drive app to save local space temporarily.

If you want, I can guide you step-by-step (tap-by-tap) to create the repository and upload files from your phone. Reply 'LANJUT' to get step-by-step taps for GitHub mobile/web UI.
